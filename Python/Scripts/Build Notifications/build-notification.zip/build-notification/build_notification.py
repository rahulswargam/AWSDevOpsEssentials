import boto3
import requests
import pymysql
import os
import json
import base64
from datetime import datetime

sns = boto3.client('sns')
codebuild = boto3.client('codebuild')
logs = boto3.client('logs')
ses = boto3.client('ses')

def extract_environment_variable(build, key_name):
    env_vars = build['environment']['environmentVariables']
    for var in env_vars:
        if var['name'] == key_name:
            return var['value']
    return 'Unknown'

def get_base64_image(s3_bucket, build_status):
    status_to_image = {
        'SUCCEEDED': 'image-files/success.png',
        'FAILED': 'image-files/failure.png',
        'IN_PROGRESS': 'image-files/inprogress.png'
    }

    s3 = boto3.client('s3')
    s3_key = status_to_image.get(build_status)

    if not s3_key:
        return None

    file_obj = s3.get_object(Bucket=s3_bucket, Key=s3_key)
    file_content = file_obj['Body'].read()

    base64_image = base64.b64encode(file_content).decode('utf-8')
    return base64_image

def send_notification_to_teams(build, build_status, webhook_url, base64_image, client_name, instance_type, request_timestamp, deployed_by, deployer_object_id, project_name, config_values, log_link=None):
    color = "Good" if build_status == "SUCCEEDED" else "Accent" if build_status == "IN_PROGRESS" else "Attention"
    
    if log_link and build_status == "FAILED":
        adaptive_card_content = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "type": "AdaptiveCard",
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "version": "1.2",
                        "body": [
                            {
                                "type": "ColumnSet",
                                "columns": [
                                    {
                                        "type": "Column",
                                        "width": "auto",
                                        "items": [
                                            {
                                                "type": "Image",
                                                "url": f"data:image/png;base64,{base64_image}",
                                                "size": "Medium",
                                                "style": "person"
                                            }
                                        ]
                                    },
                                    {
                                        "type": "Column",
                                        "width": "stretch",
                                        "items": [
                                            {
                                                "type": "RichTextBlock",
                                                "inlines": [
                                                    {
                                                        "type": "TextRun",
                                                        "text": "Status of Latest Build: ",
                                                        "weight": "Bolder",
                                                        "size": "Large",
                                                        "style": "default"
                                                    },
                                                    {
                                                        "type": "TextRun",
                                                        "text": build_status.upper(),
                                                        "weight": "Bolder",
                                                        "size": "Large",
                                                        "color": color,
                                                        "style": "default"
                                                    }
                                                ]
                                            },
                                            {
                                                "type": "TextBlock",
                                                "text": "Details of the CodeBuild Project:",
                                                "size": "medium",
                                                "style": "default"
                                            },
                                            {
                                                "type": "ColumnSet",
                                                "columns": [
                                                    {
                                                        "type": "Column",
                                                        "width": "auto",
                                                        "items": [
                                                            {"type": "TextBlock", "text": "Deployed By", "weight": "Bolder", "spacing": "Small"},                                        
                                                            {"type": "TextBlock", "text": "Client Name", "weight": "Bolder"},
                                                            {"type": "TextBlock", "text": "Instance Type", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "Timestamp of Deploy", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "ETL Automation", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "ETL V2 App", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "Version Category", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "App Version Override", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": "Build Log", "weight": "Bolder", "spacing": "Small"}
                                                        ]
                                                    },
                                                    {
                                                        "type": "Column",
                                                        "width": "auto",
                                                        "items": [
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": ":", "weight": "Bolder", "spacing": "Small"}
                                                        ]
                                                    },
                                                    {
                                                        "type": "Column",
                                                        "width": "stretch",
                                                        "items": [
                                                            {"type": "TextBlock", "text": f"<at>{deployed_by}</at>", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{client_name}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{instance_type}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{request_timestamp}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{config_values.get('etl_automation_enabled', 'N/A')}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{config_values.get('etl_v2_application_enabled', 'N/A')}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{config_values.get('version_category', 'N/A')}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"{config_values.get('application_version_override', 'N/A')}", "spacing": "Small"},
                                                            {"type": "TextBlock", "text": f"[View Logs]({log_link})", "spacing": "Small"},
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        "msteams": {
                            "width": "Full",
                            "entities": [
                                {
                                    "type": "mention",
                                    "text": f"<at>{deployed_by}</at>",
                                    "mentioned": {
                                        "id": deployer_object_id,
                                        "name": deployed_by
                                    }
                                }
                            ]
                        }
                    }
                }
            ]
        }
    
        response = requests.post(webhook_url, json=adaptive_card_content)
        print("Response from MS Teams:", response.status_code, response.text)
        return response.text

def extract_config_values(updated_config_json, original_config_json):
    keys_of_interest = {
        'etl_automation_enabled': ('etl', 'etl_automation_enabled'),
        'etl_v2_application_enabled': ('etl', 'etl_v2_application_enabled'),
        'version_category': ('shared', 'version_category'),
        'application_version_override': ('shared', 'application_version_override')
    }

    default_values = {key: 'N/A' for key in keys_of_interest}

    extracted_values = default_values.copy()

    try:
        updated_config = json.loads(updated_config_json) if isinstance(updated_config_json, str) else updated_config_json or {}
    except json.JSONDecodeError as e:
        print("Error decoding 'updated_config_json':", e)
        print("Value of 'updated_config_json':", updated_config_json)
        updated_config = {}

    try:
        original_config = json.loads(original_config_json) if isinstance(original_config_json, str) else original_config_json or {}
    except json.JSONDecodeError as e:
        print("Error decoding 'original_config_json':", e)
        print("Value of 'original_config_json':", original_config_json)
        original_config = {}

    for key, path in keys_of_interest.items():
        value = get_value_by_path(updated_config, path) or get_value_by_path(original_config, path)
        extracted_values[key] = value if value is not None else 'N/A'

    return extracted_values

def get_value_by_path(config_dict, path):
    for step in path:
        if not isinstance(config_dict, dict) or step not in config_dict:
            return None
        config_dict = config_dict[step]
    return config_dict if not isinstance(config_dict, dict) else None

def send_failure_email(build, last_100_lines):
    environment_variables = build['environment']['environmentVariables']
    build_number = build['buildNumber']
    environment_name = extract_environment_variable(build, 'ENVIRONMENT_NAME')
    instance_name = extract_environment_variable(build, 'INSTANCE_NAME')

    subject = f"{environment_name} » {instance_name} - Build # {build_number} - Failed"
    message = f"{environment_name} » {instance_name} - Build # {build_number} - Failed\n\n\nHere are the last 100 lines of the logs of the CodeBuild Project:\n\n\n{last_100_lines}"

    ses.send_email(
        Source=f"alert@{environment_name}.streamlyne.org",
        Destination={'ToAddresses': ['rswargam@streamlyne.com']},
        Message={
            'Subject': {'Data': subject},
            'Body': {'Text': {'Data': message}}
        }
    )

def lambda_handler(event, context):
    print("Received event:", event)

    sns_message = json.loads(event['Records'][0]['Sns']['Message'])
    print("SNS Message:", sns_message)

    build_id = sns_message['detail']['build-id']

    build_details_response = codebuild.batch_get_builds(ids=[build_id])
    if not build_details_response or 'builds' not in build_details_response or not build_details_response['builds']:
        return {
            'statusCode': 400,
            'body': json.dumps('Error: Unable to fetch build details.')
        }

    build = build_details_response['builds'][0]
    build_status = build['buildStatus']

    host = os.environ['DB_HOST']
    user = os.environ['DB_USERNAME']
    password = os.environ['DB_PASSWORD']
    db_name = os.environ['DB_NAME']

    deployment_table = 'self_service_app_codebuilddeployment'
    user_table = 'self_service_app_sluser'

    connection = None

    try:
        connection = pymysql.connect(host=host, user=user, password=password, db=db_name, cursorclass=pymysql.cursors.DictCursor)

        with connection.cursor() as cursor:
            deployment_query = f"""
                SELECT client_name, instance_type, request_timestamp, user_id 
                FROM {deployment_table} 
                ORDER BY request_timestamp DESC 
                LIMIT 1
            """
            cursor.execute(deployment_query)
            latest_deployment = cursor.fetchone()

            if latest_deployment:
                request_timestamp = latest_deployment['request_timestamp'].strftime('%Y-%m-%d %H:%M:%S')
                deployer_query = f"""
                    SELECT first_name, sso_object_id
                    FROM {user_table} 
                    WHERE id = %s
                """
                cursor.execute(deployer_query, (latest_deployment['user_id'],))
                deployer = cursor.fetchone()

                deployer_name = deployer['first_name'] if deployer else 'Unknown'
                deployer_object_id = deployer['sso_object_id'] if deployer else 'Unknown'

                project_type = "dev"
                client_name = latest_deployment['client_name']
                instance_type = latest_deployment['instance_type']
                project_name = f"{project_type}_{client_name}_{instance_type}_deploy"

                config_query = f"""
                    SELECT updated_deploy_config, original_deploy_config 
                    FROM `{deployment_table}` 
                    ORDER BY request_timestamp DESC 
                    LIMIT 1
                """
                cursor.execute(config_query)
                config_result = cursor.fetchone()
                
                if config_result:
                    updated_config = config_result['updated_deploy_config']
                    original_config = config_result['original_deploy_config']
                    config_values = extract_config_values(updated_config, original_config)

        connection.commit()

        base64_image = get_base64_image(s3_bucket, build_status)
        log_link = None
        
        if build_status == "FAILED":
            log_link = build['logs']['deepLink']
            log_events = logs.get_log_events(logGroupName=build['logs']['groupName'], logStreamName=build['logs']['streamName'])
            logs_data = [event['message'] for event in log_events['events']]
            last_100_lines = "\n".join(logs_data[-100:])
            send_failure_email(build, last_100_lines)
            
        else:
            if 'logs' in build and 'deepLink' in build['logs']:
                log_link = build['logs']['deepLink']
        
        if base64_image:
            
            response = send_notification_to_teams(build, build_status, webhook_url, base64_image, client_name, instance_type, request_timestamp, deployer_name, deployer_object_id, project_name, config_values, log_link)
        else:
            print(f"No image found for status: {build_status}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
        
    finally:
        if connection and hasattr(connection, 'open') and connection.open:
            connection.close()

    return {
        'statusCode': 200,
        'body': json.dumps('Process completed successfully.')
    }

s3_bucket = 'cicd-python-files'
webhook_url = 'https://vivantech.webhook.office.com/webhookb2/8cd21dc6-62ae-47e5-9772-259fdaf5c708@9794d907-c605-4910-9050-02b9980d3e7a/IncomingWebhook/806301631f9347b7aa58b7447904638c/b3691802-f075-45f0-9e42-47b02642f96c'